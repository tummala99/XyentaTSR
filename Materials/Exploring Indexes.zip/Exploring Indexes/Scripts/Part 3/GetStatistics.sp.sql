Use TestDB
GO
IF OBJECT_ID ('dbo.GetStatistics') IS NOT NULL
	DROP PROCEDURE dbo.GetStatistics
GO
CREATE PROC dbo.GetStatistics 
	@col nvarchar(100) = NULL
AS
BEGIN
	DECLARE @distinctcount INT
	DECLARE @sqlstr NVARCHAR(2000)
	DECLARE @ParmDefinition nvarchar(500);

--	SET @sqlstr = N'SELECT @distinctcountOUT = COUNT(*) FROM 
--		(SELECT DISTINCT ' + @col + N' FROM T1) dt'
--	SET @ParmDefinition = N'@distinctcountOUT INT OUTPUT';

--	EXECUTE sp_executesql @sqlstr, @ParmDefinition, @distinctcountOUT = @distinctcount OUTPUT

SET @sqlstr = 
'SELECT ' + '''' + @col + '''' + ' ,
COUNT(*) AS [Rows], 
COUNT(DISTINCT(' + @col + ' )) as [Distinct],
COUNT(DISTINCT(' + @col + ' ))/cast(COUNT(c1) as float) AS Density,
COUNT(DISTINCT(' + @col + ' ))/cast(COUNT(c1) as float) * 100 AS [Density %],
1/cast(COUNT(DISTINCT(ISNULL(' + @col + ' , -1))) as float) AS [All Density],
1/cast(COUNT(DISTINCT(ISNULL(' + @col + ' , -1))) as float) * 100 AS [All Density %],
COUNT(DISTINCT(ISNULL(' + @col + ' , -1)))  AS [Selectivity],
COUNT(DISTINCT(ISNULL(' + @col + ' , -1)))/cast(COUNT(*) as float) * 100  AS [Selectivity %]
FROM t1';

--print @sqlstr
	EXECUTE sp_executesql @sqlstr	
RETURN (0)
END
GO

-- Testing
 --EXEC GetStatistics c1
-- EXEC GetStatistics 'c1, c2'

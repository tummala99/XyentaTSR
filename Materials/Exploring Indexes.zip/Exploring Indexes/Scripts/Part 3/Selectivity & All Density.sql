Use TestDB
SET NOCOUNT ON
IF(SELECT OBJECT_ID('t1')) IS NOT NULL
  DROP TABLE t1
GO
CREATE TABLE t1(c1 INT, c2 INT, c3 INT, c4 INT)

DECLARE @n INT
SET @n = 1
WHILE @n <= 5000
BEGIN
  INSERT INTO t1 VALUES(@n, @n%50, @n%100, '100')
  SET @n = @n + 1
END

-- extra rows to make the first column values having NULL value
DECLARE @n INT
SET @n = 5001
WHILE @n <= 5500
BEGIN
  INSERT INTO t1 VALUES(NULL, @n%50, @n%100, '100') 
  SET @n = @n + 1
END

-- now create index on every column
CREATE INDEX i1 ON t1 (c1)
CREATE INDEX i2 ON t1 (c2)
CREATE INDEX i3 ON t1 (c3)
CREATE INDEX i4 ON t1 (c4)

-- get the report on density & all density for all indexes
-- get the report on density & all density for all indexes
--SELECT 'Col1',
--COUNT(c1) AS [Rows],
--COUNT(DISTINCT(c1)) as [Distinct],
--COUNT(DISTINCT(c1))/cast(COUNT(c1) as float) AS Density,
--COUNT(DISTINCT(c1))/cast(COUNT(c1) as float) * 100 AS [Density %],
--1/cast(COUNT(DISTINCT(c1)) as float) AS [All Density],
--1/cast(COUNT(DISTINCT(c1)) as float) * 100 AS [All Density %],
--COUNT(DISTINCT(c1))  AS [Selectivity]
--FROM t1

EXEC GetStatistics 'c1'
EXEC GetStatistics 'c2'
EXEC GetStatistics 'c3'
EXEC GetStatistics 'c4'

-- Defining Selectivity based on above query
-- Selectivity tells the number of unique rows returned for the specific index
-- As an example using Col1 will return 5000 unique rows, c4 will return 1 unique row


-- will it use c1 for index seek or scan?
SELECT * FROM T1 WHERE C1 = 4 

-- which column will it use for seek - c2, c3, c4?
SELECT * FROM t1 WHERE c2 = 4 AND c3 = 4 AND c1 = 100

-- discuss the prev query result to understand the concept
-- now guess what is expected in the foll case?
SELECT * FROM t1 WHERE c2 = 4 AND c3 = 4 AND c4 = 100

-- All of the above queries uses Selectivity to find out which 
-- index to use. if the index is too low, there is no point in using it

-- all of the following uses Hash Join
-- hash join has 2 elements build input & probe input
-- the smaller result is build input & the large one probe input
-- the execution plan shows probe input
-- All Density is the % of rows that would be returned. Hence a higher
-- value means large result set & it should become the probe input result set

-- what will be the probe input in the foll case?
SELECT * FROM t1 tab1
JOIN t1 tab2 ON tab1.c1 = tab2.c2

SELECT * FROM t1 tab1
JOIN t1 tab2 ON tab1.c2 = tab2.c4

SELECT * FROM t1 tab1
JOIN t1 tab2 ON tab1.c2 = tab2.c3

-- discuss the last query & why the probe uses c3 even though c2 has
-- lower selectivity?
-- Change the last query into the following way (it gives the same result set)
SELECT * FROM t1 tab1
JOIN t1 tab2 ON tab1.c3 = tab2.c2

-- Now check the probe detail on the exec plan. Do you see any difference? Focus
-- on the probe residual & its left and right side column names. How is it
-- different from the way they are specified in the query?

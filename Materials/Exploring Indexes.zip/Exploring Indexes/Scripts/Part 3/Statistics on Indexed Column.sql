Use TestDB
SET NOCOUNT ON
IF(SELECT OBJECT_ID('t1')) IS NOT NULL
  DROP TABLE t1
GO
CREATE TABLE t1(c1 INT, c2 INT)
CREATE INDEX idx ON t1 (c1)

DECLARE @n INT
SET @n = 1
WHILE @n <= 20
BEGIN
  INSERT INTO t1 VALUES(@n, @n)
  SET @n = @n + 1
END

-- the following dbcc command shows no statistics
DBCC SHOW_STATISTICS ('t1', idx)

-- recreate the index and check the statistics
CREATE INDEX idx ON t1 (c1) WITH DROP_EXISTING
DBCC SHOW_STATISTICS ('t1', idx)

DECLARE @n INT
SET @n = 21
WHILE @n <= 1000
BEGIN
  INSERT INTO t1 VALUES(@n, @n)
  SET @n = @n + 1
END

-- will the statistics be updated?
-- note that the time will not show seconds. hence wait for a min to pass
DBCC SHOW_STATISTICS ('t1', idx)

-- use the following query. Will the stats be updated now?
SELECT * FROM t1 WHERE c1 = 120
DBCC SHOW_STATISTICS ('t1', idx)


Use TestDB
SET NOCOUNT ON
IF(SELECT OBJECT_ID('t1')) IS NOT NULL
  DROP TABLE t1
GO
CREATE TABLE t1(c1 INT, c2 numeric)

DECLARE @n INT
SET @n = 1
WHILE @n <= 500
BEGIN
  INSERT INTO t1 VALUES(@n, @n%200) 
  SET @n = @n + 1
END
-- extra rows to make the column values different than sample
INSERT INTO t1 VALUES(11, 10)
INSERT INTO t1 VALUES(11, 10)
 
CREATE INDEX i1 ON t1 (c1)
CREATE INDEX i2 ON t1 (c2)

-- check the stat details
DBCC SHOW_STATISTICS ('t1', i1)

-- RANGE_ROWS (no of rows within the range (exlcusing the RANGE_HI_KEY)
SELECT COUNT(*) FROM t1 WHERE c1 > 1 AND c1 < 4

-- EQ_ROWS (no of rows exactly equal to RANGE_HI_KEY)
SELECT COUNT(*) FROM t1 WHERE c1 = 11

-- DISTINCT_RANGE_ROWS (distinct rows within the range)
SELECT COUNT(DISTINCT(c1)) FROM t1 WHERE c1 > 1 AND c1 < 4

-- check the statistics of i2 to calculate AVG_RANGE_ROWS
DBCC SHOW_STATISTICS ('t1', i2)

-- AVG_RANGE_ROWS (avg no of rows per distinct values within the range)
-- Also equals to RANGE_ROWS / DISTINCT_RANGE_ROWS
SELECT COUNT(c2)/COUNT(DISTINCT(c2)) FROM t1 WHERE c2 > 0 AND c2 < 2



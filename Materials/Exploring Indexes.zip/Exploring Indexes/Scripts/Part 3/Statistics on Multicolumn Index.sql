Use TestDB
SET NOCOUNT ON
IF(SELECT OBJECT_ID('t1')) IS NOT NULL
  DROP TABLE t1
GO
CREATE TABLE t1(c1 INT, c2 INT, c3 INT, c4 INT)

DECLARE @n INT
SET @n = 1
WHILE @n <= 5000
BEGIN
  INSERT INTO t1 VALUES(@n, @n%10, @n%20, @n%50)
  SET @n = @n + 1
END

-- now create index on every column
CREATE INDEX i1 ON t1 (c1)
CREATE INDEX i234 ON t1 (c2, c3, c4)

-- get the report on density & all density for all indexes
-- get the report on density & all density for all indexes
SELECT 'Col1',
COUNT(c1) AS [Rows],
COUNT(DISTINCT(c1)) as [Distinct],
COUNT(DISTINCT(c1))/cast(COUNT(c1) as float) AS Density,
COUNT(DISTINCT(c1))/cast(COUNT(c1) as float) * 100 AS [Density %],
1/cast(COUNT(DISTINCT(c1)) as float) AS [All Density],
1/cast(COUNT(DISTINCT(c1)) as float) * 100 AS [All Density %],
COUNT(DISTINCT(c1))  AS [Selectivity]
FROM t1

DECLARE @distinct INT
SELECT @distinct = COUNT(*) FROM (SELECT DISTINCT c2 FROM T1) dt

SELECT 'Col2',
COUNT(*) AS [Rows],
@distinct as [Distinct],
@distinct/cast(COUNT(*) as float) AS Density,
@distinct/cast(COUNT(*) as float) * 100 AS [Density %],
1/cast(@distinct as float) AS [All Density],
1/cast(@distinct as float) * 100 AS [All Density %],
@distinct AS [Selectivity]
FROM t1

SELECT @distinct = COUNT(*) FROM (SELECT DISTINCT c2, c3 FROM T1) dt

SELECT 'Col2 Col3',
COUNT(*) AS [Rows],
@distinct as [Distinct],
@distinct/cast(COUNT(*) as float) AS Density,
@distinct/cast(COUNT(*) as float) * 100 AS [Density %],
1/cast(@distinct as float) AS [All Density],
1/cast(@distinct as float) * 100 AS [All Density %],
@distinct AS [Selectivity]
FROM t1

SELECT @distinct = COUNT(*) FROM (SELECT DISTINCT c2, c3, c4 FROM T1) dt

SELECT 'Col2 Col3 Col4',
COUNT(*) AS [Rows],
@distinct as [Distinct],
@distinct/cast(COUNT(*) as float) AS Density,
@distinct/cast(COUNT(*) as float) * 100 AS [Density %],
1/cast(@distinct as float) AS [All Density],
1/cast(@distinct as float) * 100 AS [All Density %],
@distinct AS [Selectivity]
FROM t1


-- will it use c1 for index seek?
SELECT * FROM T1 WHERE C1 = 4 

-- will the following query use index see or scan?
-- the decision is made on the column combination in WHERE clause & its 
-- corresponding selectivity
SELECT * FROM t1 WHERE c2 = 4 AND c3 = 4 AND c4 = 100
SELECT * FROM t1 WHERE c3 = 4 AND c4 = 4
SELECT * FROM t1 WHERE c2 = 4 AND c3 = 4
SELECT * FROM t1 WHERE c2 = 4 

-- discuss why there is table scan and not Index Scan?


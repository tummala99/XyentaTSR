Use TestDB
SET NOCOUNT ON
IF(SELECT OBJECT_ID('t1')) IS NOT NULL
  DROP TABLE t1
GO
CREATE TABLE t1(c1 INT, c2 INT, c3 INT, c4 INT)

DECLARE @n INT
SET @n = 1
WHILE @n <= 5000
BEGIN
  INSERT INTO t1 VALUES(@n, @n%50, @n%100, '100')
  SET @n = @n + 1
END

-- now create index on every column
CREATE INDEX i1 ON t1 (c1)
CREATE INDEX i2 ON t1 (c2)
CREATE INDEX i3 ON t1 (c3)
CREATE INDEX i4 ON t1 (c4)

-- get the report on density & all density for all indexes
EXEC GetStatistics 'c1'
EXEC GetStatistics 'c2'
EXEC GetStatistics 'c3'
EXEC GetStatistics 'c4'

-- will it use c1 for index seek?
SELECT * FROM T1 WHERE C1 = 4 

-- which column will it use for seek - c2, c3, c4?
SELECT * FROM t1 WHERE c2 = 4 AND c3 = 4 AND c1 = 100

-- discuss the prev query result to understand the concept
-- now guess what is expected in the foll case?
SELECT * FROM t1 WHERE c2 = 4 AND c3 = 4 AND c4 = 100

-- All of the above queries uses Selectivity to find out which 
-- index to use. if the index is too low, there is no point in using it

-- all of the following uses Hash Join
-- hash join has 2 elements build input & probe input
-- the smaller result is build input & the large one probe input
-- the execution plan shows probe input
-- All Density is the % of rows that would be returned. Hence a higher
-- value means large result set & it should become the probe input result set

-- what will be the probe input in the foll case?
SELECT * FROM t1 tab1
JOIN t1 tab2 ON tab1.c1 = tab2.c2

SELECT * FROM t1 tab1
JOIN t1 tab2 ON tab1.c2 = tab2.c4

SELECT * FROM t1 tab1
JOIN t1 tab2 ON tab1.c2 = tab2.c3

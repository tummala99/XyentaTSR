Use TestDB
SET NOCOUNT ON
--Create first table with 10001 rows
IF(SELECT OBJECT_ID('t1')) IS NOT NULL
  DROP TABLE t1
GO
CREATE TABLE t1(t1_c1 INT IDENTITY, t1_c2 INT)
INSERT INTO t1 (t1_c2) VALUES(1) 
DECLARE @n INT
SET @n = 0
WHILE @n < 10000
BEGIN
  INSERT INTO t1 (t1_c2) VALUES(2)
  SET @n = @n + 1
END
GO
CREATE CLUSTERED INDEX i1 ON t1(t1_c1)

--Create second table with 10001 rows,
-- but opposite data distribution
IF(SELECT OBJECT_ID('t2')) IS NOT NULL
  DROP TABLE t2
GO
CREATE TABLE t2(t2_c1 INT IDENTITY, t2_c2 INT)
INSERT INTO t2 (t2_c2) VALUES(2)
DECLARE @n INT
SET @n = 0
WHILE @n < 10000
BEGIN
  INSERT INTO t2 (t2_c2) VALUES(1)
  SET @n = @n + 1
END
GO
CREATE CLUSTERED INDEX i1 ON t2(t2_c1)

-- Check whether the auto update stats is on
SELECT DATABASEPROPERTYEX('TestDB', 'IsAutoCreateStatistics')

-- disable auto create statistics first to see the impact when
-- no stats is created for the non indexed column
ALTER DATABASE TestDB SET AUTO_CREATE_STATISTICS OFF
SELECT DATABASEPROPERTYEX('TestDB', 'IsAutoCreateStatistics')

-- stat details are stored in sys.stats
SELECT * FROM sys.stats WHERE OBJECT_NAME(OBJECT_ID) = 't1'
SELECT * FROM sys.stats WHERE OBJECT_NAME(OBJECT_ID) = 't2'

-- sample table looks like (execute both lines at the same time)
SELECT t1_c2, COUNT(*) FROM t1 GROUP BY t1_c2
SELECT t2_c2, COUNT(*) FROM t2 GROUP BY t2_c2

-- use the following query to get a large resultset from t1 
-- & small resultset from t2 (switch on exec plan)
SET STATISTICS IO ON
SELECT t1.t1_c2, t2.t2_c2 FROM t1
JOIN t2 ON t1.t1_c2 = t2.t2_c2 -- join gives total 20000 rows
	AND t1.t1_c2 = 2 -- filters the join to give just 10000 rows from t1
SET STATISTICS IO OFF

-- the above query actually means
	-- get all the rows from t1 where t1_c2 = 2
	-- get all the rows from t2 where t2_c2 = 2 AND
		-- get all the rows from t2 where t2_c2 <> 2	-- as there was no 
														-- stats for t2_c2, it has get everything
	-- join the above two result set

-- recheck the stat no
SELECT * FROM sys.stats WHERE OBJECT_NAME(OBJECT_ID) = 't1'
SELECT * FROM sys.stats WHERE OBJECT_NAME(OBJECT_ID) = 't2'

-- enable auto create stats
ALTER DATABASE TestDB SET AUTO_CREATE_STATISTICS ON
SELECT DATABASEPROPERTYEX('TestDB', 'IsAutoCreateStatistics')

-- re execute the query
SET STATISTICS IO ON
SELECT t1.t1_c2, t2.t2_c2 FROM t1
JOIN t2 ON t1.t1_c2 = t2.t2_c2 -- join gives total 20000 rows
	AND t1.t1_c2 = 2 -- filters the join to give just 10000 rows from t1
SET STATISTICS IO OFF

-- discuss the changed exec plan. To understand it better check the 
-- new stats created. Note that the first Scan is now on t2_c2 and
-- not t1_c2 because the optimizer found that t2_c2 provides better
-- selectivity & will return less row than t1_c2

-- check the stats details
SELECT * FROM sys.stats WHERE OBJECT_NAME(OBJECT_ID) = 't1'
SELECT * FROM sys.stats WHERE OBJECT_NAME(OBJECT_ID) = 't2'

DBCC SHOW_STATISTICS (t1, _WA_Sys_00000002_664B26CC)
DBCC SHOW_STATISTICS (t2, _WA_Sys_00000002_673F4B05)

-- to see the impact change the query & ask how the plan
-- will look now (in another window show the curr stats with dbcc)
SET STATISTICS IO ON
SELECT t1.t1_c2, t2.t2_c2 FROM t1
JOIN t2 ON t1.t1_c2 = t2.t2_c2 
	AND t1.t1_c2 = 1 -- changed from 2 to 1
SET STATISTICS IO OFF


--- Command to drop statistics
--DROP STATISTICS t1._WA_Sys_00000002_664B26CC
--DROP STATISTICS t2._WA_Sys_00000002_673F4B05


Use TestDB
SET NOCOUNT ON
IF(SELECT OBJECT_ID('t1')) IS NOT NULL
  DROP TABLE t1
GO
CREATE TABLE t1(c1 INT, c2 INT) 

DECLARE @n INT
SET @n = 1
WHILE @n <= 5000
BEGIN
  INSERT INTO t1 VALUES(@n, @n%10)
  SET @n = @n + 1
END

-- insert 100 rows with c1 value as 345
DECLARE @n INT
SET @n = 1
WHILE @n <= 100
BEGIN
  INSERT INTO t1 VALUES(345, @n%10)
  SET @n = @n + 1
END

CREATE INDEX i1 ON t1 (c1) 

-- list the selectivity first
EXEC GetStatistics 'c1'

-- will it be Index Seek / Scan
SELECT * FROM t1 WHERE c1 = 344
SELECT * FROM t1 WHERE c1 = 345

-- check the stats
DBCC SHOW_STATISTICS (t1, i1)
-- check the histogram for the RANGE_HI_KEY = 345 and EQ_ROWS
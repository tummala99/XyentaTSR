Use TestDB
SET NOCOUNT ON
IF(SELECT OBJECT_ID('t1')) IS NOT NULL
  DROP TABLE t1
GO
-- create a table with 10 rows
CREATE TABLE t1(c1 CHAR(800), c2 INT IDENTITY)
DECLARE @n INT
SET @n = 1
WHILE @n <= 10
BEGIN
  INSERT INTO t1 (c1) VALUES(@n)
  SET @n = @n + 1
END
-- create an index. it will update the stats
CREATE INDEX i1 ON t1(c1) 

-- check the stats
DBCC SHOW_STATISTICS (t1, 'i1')

-- disable auto update stats
ALTER DATABASE TestDB SET AUTO_UPDATE_STATISTICS OFF

-- check the execution plan for the foll query
SELECT * FROM t1 WHERE c1 = '2'

-- check the stats (it is not updated now)
DBCC SHOW_STATISTICS (t1, 'i1')

-- insert another set of 100 rows
DECLARE @n INT
SET @n = 11
WHILE @n <= 101
BEGIN
  INSERT INTO t1 (c1) VALUES(@n)
  SET @n = @n + 1
END

-- check the exec plan now
SELECT * FROM t1 WHERE c1 = '2'

-- enable the auto update stats on the database
-- recheck the query
ALTER DATABASE TestDB SET AUTO_UPDATE_STATISTICS ON
SELECT * FROM t1 WHERE c1 = '2'

-- the stats is not updated? Discuss the reason why not?
-- The last code in this page gives the reason
DBCC SHOW_STATISTICS (t1, 'i1')

-- Let us manually update the stats
-- it will show the new rows in Rows/Rows Sampled col
UPDATE STATISTICS t1 (i1) 
DBCC SHOW_STATISTICS (t1, 'i1')

-- check the exec plan & stats
SELECT * FROM t1 WHERE c1 = '2'

-- insert another set of rows & check stats
DECLARE @n INT
SET @n = 101
WHILE @n <= 200
BEGIN
  INSERT INTO t1 (c1) VALUES(@n)
  SET @n = @n + 1
END

-- will the stats be updated now?
SELECT * FROM t1 WHERE c1 = '2'
DBCC SHOW_STATISTICS (t1, 'i1')

-- the stats are updated only when a minimum % of rows is inserted
-- insert 500 rows & then run the select query
DECLARE @n INT
SET @n = 201
WHILE @n <= 1000
BEGIN
  INSERT INTO t1 (c1) VALUES(@n)
  SET @n = @n + 1
END

-- without manual update stats, the stats will be updated on
-- running the foll select query
SELECT * FROM t1 WHERE c1 = '2'
DBCC SHOW_STATISTICS (t1, 'i1')


Use TestDB
SET NOCOUNT ON
IF(SELECT OBJECT_ID('t1')) IS NOT NULL
  DROP TABLE t1
GO
CREATE TABLE t1(c1 INT, c2 INT)
CREATE CLUSTERED INDEX ci ON t1(c1)
INSERT INTO t1 VALUES(11, 12)

SET STATISTICS IO ON
UPDATE t1 SET c1 = 11 WHERE c1 = 11
SET STATISTICS IO OFF

-- now add a NCI
CREATE NONCLUSTERED INDEX nci ON t1(c2)

-- check the impact on logical read
-- note: the query does not refer to the NCI
SET STATISTICS IO ON
UPDATE t1 SET c1 = 11 WHERE c1 = 11
SET STATISTICS IO OFF

-- why is there a difference even though the NCI is not present
-- in the query?
-- The NCI is also updated with the new value of the CI c1 value

-- verify it by updating only the NCI column. See the impact on the read.
SET STATISTICS IO ON
UPDATE t1 SET c2 = 11 WHERE c1 = 11
SET STATISTICS IO OFF

Use TestDB
GO
IF OBJECT_ID ('dbo.demo') IS NOT NULL
	DROP TABLE dbo.demo

-- the a primary key creates a CI
CREATE TABLE demo (col1 INT PRIMARY KEY, col2 INT)

-- check the new index
SELECT * FROM sys.indexes WHERE object_name(object_id) = 'demo'

-- try to drop it
DROP INDEX [PK__demo__373B3228] ON [dbo].[demo] 

-- table with UNIQUE column
IF OBJECT_ID ('dbo.demo') IS NOT NULL
	DROP TABLE dbo.demo
-- what is expected in the following case
CREATE TABLE demo (col1 INT UNIQUE, col2 INT)
-- how many rows will be present in the sys.indexes?
SELECT * FROM sys.indexes WHERE object_name(object_id) = 'demo'

-- table with IDENTITY property
IF OBJECT_ID ('dbo.demo') IS NOT NULL
	DROP TABLE dbo.demo
-- what is expected in the following case
CREATE TABLE demo (col1 INT IDENTITY, col2 INT)
-- check the indexes & column details
SELECT * FROM sys.indexes WHERE object_name(object_id) = 'demo'
SELECT * FROM sys.columns WHERE object_name(object_id) = 'demo'

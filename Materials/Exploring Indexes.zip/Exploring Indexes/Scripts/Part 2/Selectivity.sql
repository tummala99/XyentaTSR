Use TestDB
SET NOCOUNT ON
IF(SELECT OBJECT_ID('t1')) IS NOT NULL
  DROP TABLE t1
GO
CREATE TABLE t1(c1 INT, c2 INT, c3 CHAR(50))
-- module operation provides only 2 values 0 & 1
DECLARE @n INT
SET @n = 1
WHILE @n <= 2000
BEGIN
  INSERT INTO t1 VALUES(@n, @n%2, 'c3')
  SET @n = @n + 1
END

-- get the Selectivity
-- higher selectivity means better index
SELECT 'c1 selectivity', (COUNT(DISTINCT c1) / CAST(COUNT(*) AS FLOAT))*100 FROM t1
SELECT 'c2 selectivity', (COUNT(DISTINCT c2) / CAST(COUNT(*) AS FLOAT))*100 FROM t1

-- create index on higher selectivity column
CREATE INDEX idx ON t1 (c1)

-- check the statement
SET STATISTICS IO ON
SELECT * FROM T1 WHERE C1=1 AND c2=1
SET STATISTICS IO OFF

-- create index on low selectivity column
-- dropping the existing index on the same line
CREATE INDEX idx ON t1 (c2) WITH DROP_EXISTING

-- recheck the statement
-- it does not use the index (remember cost based optimzation)
SET STATISTICS IO ON
SELECT * FROM T1 WHERE C1=1 AND c2=1
SET STATISTICS IO OFF

-- force the query to use the index
SET STATISTICS IO ON
SELECT * FROM T1 WITH (INDEX(idx)) WHERE C1=1 AND c2=1 
SET STATISTICS IO OFF





Use TestDB
SET NOCOUNT ON
IF (SELECT OBJECT_ID('T1')) IS NOT NULL
	DROP TABLE T1
GO
-- create a table with no index
CREATE TABLE T1(C1 INT, C2 INT, C3 CHAR(50))
DECLARE @n INT
SET @n = 1
WHILE @n < 15000
BEGIN
	INSERT INTO T1 VALUES (@n, @n, 'C3')
	SET @n = @n + 1
END

-- check the logical read (switch ON the exec plan)
SET STATISTICS IO ON
UPDATE T1 SET C1 = 1, C2 = 1 WHERE C2 = 1
SET STATISTICS IO OFF

-- why is the logical read such a high value
-- because it has to completely scan the table till the end
-- to find out if any row has column C2 = 1

-- create a index on C1
CREATE CLUSTERED INDEX I1 ON T1 (C1)

-- check the logical read. Increased value is index overhead
SET STATISTICS IO ON
UPDATE T1 SET C1 = 1, C2 = 1 WHERE C2 = 1
SET STATISTICS IO OFF

-- now create a index on C2
CREATE INDEX I2 ON T1 (C2)

-- check the logical read. see the improvement due to proper indexing
SET STATISTICS IO ON
UPDATE T1 SET C1 = 1, C2 = 1 WHERE C2 = 1
SET STATISTICS IO OFF

GO


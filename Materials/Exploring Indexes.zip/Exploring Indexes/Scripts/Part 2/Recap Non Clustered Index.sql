Use TestDB
SET NOCOUNT ON
GO
IF(SELECT OBJECT_ID('t1')) IS NOT NULL
  DROP TABLE t1
-- Create a table with NCI only
CREATE TABLE t1(c1 INT, c2 CHAR(50))
CREATE NONCLUSTERED INDEX i1 ON t1(c1)

DECLARE @n INT
SET @n = 1
WHILE @n <= 1500
  BEGIN
  INSERT INTO t1 (c1, c2) VALUES(@n, 'c2')
  SET @n = @n + 1
END

-- Swithc on the execution plan
-- Table Scan
SELECT * FROM t1 WHERE c1 > 1400
-- Index Seek
SELECT * FROM t1 WHERE c1 = 1400
-- Index Scan
SELECT c1 FROM t1

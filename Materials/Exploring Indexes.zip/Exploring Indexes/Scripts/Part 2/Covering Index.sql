Use TestDB
SET NOCOUNT ON
GO

IF(SELECT OBJECT_ID('t1')) IS NOT NULL
  DROP TABLE t1
GO
-- create a table with no index
CREATE TABLE t1(c1 INT, c2 INT, c3 CHAR(250))
DECLARE @n INT
SET @n = 1
WHILE @n <= 1000
BEGIN
  INSERT INTO t1 VALUES(@n%200, @n, @n)
  SET @n = @n + 1
END

-- check the read & scan
SET STATISTICS IO ON
SELECT c1, c2 FROM t1 WHERE c1 = 1
SET STATISTICS IO OFF

-- create a NCI on c1
CREATE NONCLUSTERED INDEX nci ON t1(c1)

-- will it use table scan, index scan or index seek?
SET STATISTICS IO ON
SELECT c1, c2 FROM t1 WHERE c1 = 1
SET STATISTICS IO OFF

-- change the index to cover c1 & c2
CREATE NONCLUSTERED INDEX nci ON t1(c1, c2) WITH DROP_EXISTING

-- what is expected? will it be different from previous one?
SET STATISTICS IO ON
SELECT c1, c2 FROM t1 WHERE c1 = 1
SET STATISTICS IO OFF

-- how will the execution plan look in the following cases?
SELECT c1, c2 FROM t1
SELECT c1, c2 FROM t1 ORDER BY c1, c2





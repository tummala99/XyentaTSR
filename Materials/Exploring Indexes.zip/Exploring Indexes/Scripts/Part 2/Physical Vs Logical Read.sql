Use TestDB
SET NOCOUNT ON
IF (SELECT OBJECT_ID('T1')) IS NOT NULL
	DROP TABLE T1
GO
CREATE TABLE T1(C1 INT, C2 INT, C3 CHAR(300))
DECLARE @n INT
SET @n = 1
WHILE @n < 10000
BEGIN
	INSERT INTO T1 VALUES (@n, @n, 'C3')
	SET @n = @n + 1
END

-- why is physical read 0?
SET STATISTICS IO ON
SELECT * FROM T1 
SET STATISTICS IO OFF

-- will the following statement gets physical read?
DBCC DROPCLEANBUFFERS 
SET STATISTICS IO ON
SELECT * FROM T1 
SET STATISTICS IO OFF

-- it means the dbcc command does not remove all the data from the buffer
-- there is a memory where few data resides & they are removed only after 
-- sql server is restarted or when there is a memory crunch???

-- getting some physical read
DBCC DROPCLEANBUFFERS 
SET STATISTICS IO ON
SELECT * FROM AdventureWorks.Purchasing.PurchaseOrderDetail
SET STATISTICS IO OFF

-- repeat above without dbcc
SET STATISTICS IO ON
SELECT * FROM AdventureWorks.Purchasing.PurchaseOrderDetail
SET STATISTICS IO OFF

-- repeat above with dbcc
DBCC DROPCLEANBUFFERS 
SET STATISTICS IO ON
SELECT * FROM AdventureWorks.Purchasing.PurchaseOrderDetail
SET STATISTICS IO OFF


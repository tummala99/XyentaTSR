Use TestDB
SET NOCOUNT ON
IF(SELECT OBJECT_ID('t1')) IS NOT NULL
  DROP TABLE t1
GO
CREATE TABLE t1(c1 INT, c2 INT)
DECLARE @n INT
SET @n = 1
WHILE @n <= 20
BEGIN
  INSERT INTO t1 VALUES(@n, 2)
  SET @n = @n + 1
END
-- will the following creates a CI or NCI?
CREATE INDEX i1 ON t1(c1)

-- check the size of page
-- why it shows 2 rows? what would happen if only a CI is present?
SELECT Name=name,
CASE indid
     WHEN 0 THEN 'Heap'
     WHEN 1 THEN 'Clustered Index'
     ELSE 'Nonclustered Index'
   END AS Type
  ,Pages=dpages, Rows=rowcnt
FROM sys.sysindexes WHERE id = OBJECT_ID('t1')

-- check no of logical reads
SET STATISTICS IO ON
SELECT * FROM T1 
SET STATISTICS IO OFF

-- create a bigger size index & recheck the pages occupied
DROP INDEX t1.i1
ALTER TABLE t1 ALTER COLUMN c1 CHAR(500)
CREATE INDEX i1 ON t1(c1)

-- any difference than the previous result?
SELECT Name=name,
CASE indid
     WHEN 0 THEN 'Heap'
     WHEN 1 THEN 'Clustered Index'
     ELSE 'Nonclustered Index'
   END AS Type
  ,Pages=dpages, Rows=rowcnt
FROM sys.sysindexes WHERE id = OBJECT_ID('t1')

-- now check no of logical reads
SET STATISTICS IO ON
SELECT * FROM T1 
SET STATISTICS IO OFF


Use TestDB
SET NOCOUNT ON
SET STATISTICS IO OFF

-- recreate the table with 3 columns & 100 rows
-- create CI on c1 & NCI on c2
IF(SELECT OBJECT_ID('t1')) IS NOT NULL
  DROP TABLE t1
GO
CREATE TABLE t1(c1 INT, c2 INT, c3 INT)
CREATE CLUSTERED INDEX ci ON t1 (c1) 
CREATE NONCLUSTERED INDEX nci ON t1 (c2) 

-- add 2000 rows so that index is used

DECLARE @n INT
SET @n = 1
WHILE @n <= 2000 
  BEGIN
  INSERT INTO t1 VALUES(@n, @n+2, @n+4)
  SET @n = @n + 1
END

SET STATISTICS IO ON

-- check each of the foll query (switch ON the execution plan)
-- check the scan count in the Seek Predicates of Index Seek
SELECT c1, c2, c3 FROM t1 WHERE c2 = 10 
SELECT c1, c2, c3 FROM t1 WHERE c2 = 10 or c2 = 13 or c2 = 25

-- are the following two query same?
SELECT c1, c2, c3 FROM t1 WHERE c2 = 10 or c2 = 11 or c2 = 12 or c2 = 13
SELECT c1, c2, c3 FROM t1 WHERE c2 BETWEEN 10 AND 13

-- Scan Count is the no of times a table is scanned (and not pages)

-- will the foll use seek or scan?
SELECT c1, c2, c3 FROM t1 WHERE c2 > 1000 
SELECT c1, c2, c3 FROM t1 WHERE (c2 BETWEEN 1000 AND 1200)
	OR (c2 BETWEEN 1500 AND 1600)
-- if there is a CI then there is only CI scan and not Table Scan

-- force to use the NCI
SELECT c1, c2, c3 FROM t1 WITH (INDEX (nci)) WHERE c2 > 1000 
SELECT c1, c2, c3 FROM t1 WITH (INDEX (nci)) WHERE (c2 BETWEEN 1000 AND 1200)
	OR (c2 BETWEEN 1500 AND 1600)

SET STATISTICS IO OFF

Use TestDB
SET NOCOUNT ON
GO

IF(SELECT OBJECT_ID('t1')) IS NOT NULL
  DROP TABLE t1
GO
-- create a table with indexes on each column
CREATE TABLE t1(c1 INT, c2 INT, c3 CHAR(250))
DECLARE @n INT
SET @n = 1
WHILE @n <= 5000
BEGIN
  INSERT INTO t1 VALUES(@n, @n%200, @n)
  SET @n = @n + 1
END
CREATE CLUSTERED INDEX cic1 ON t1(c1)
CREATE NONCLUSTERED INDEX ncic2 ON t1(c2)
CREATE NONCLUSTERED INDEX ncic3 ON t1(c3)

-- how will the execution plan look like?
-- will it be an seek or scan? which type of scan?

SET STATISTICS IO ON
SELECT c2, c3 FROM t1
WHERE c3 BETWEEN '100' AND '120'
SET STATISTICS IO OFF

-- get all the c3 between 100 & 120
-- scan the entire table to get the c2 
-- join the c2 & c3 values
-- It found only c3 in WHERE clause and hence used it for seek

-- option 1 to ask the optimizer to use both the clustered
-- indexes as seek instead of clustered index scan

SET STATISTICS IO ON
SELECT c2, c3 FROM t1
WHERE c3 BETWEEN '100' AND '120'
	AND c2 > 0
SET STATISTICS IO OFF

-- the above option gets all the c2 through seek
-- it gets all the c3 between 100 & 120
-- does a join between the two results
-- It is not much different from the previous execution plan

-- option 2 to force the optimizer to use the clustered index

SET STATISTICS IO ON
SELECT c2, c3 FROM t1 WITH (INDEX (ncic2, ncic3))
WHERE c3 BETWEEN '100' AND '120'
	AND c2 > 0
SET STATISTICS IO OFF

-- what is the difference between the above two options?
-- which one is better option?
-- run the following query in one step
SET STATISTICS IO ON
SELECT c2, c3 FROM t1
WHERE c3 BETWEEN '100' AND '120'
	AND c2 > 0

SELECT c2, c3 FROM t1 WITH (INDEX (ncic2, ncic3))
WHERE c3 BETWEEN '100' AND '120'
	AND c2 > 0
SET STATISTICS IO OFF

-- discuss the differences in the two execution plan.
-- in the option 1, the optimizer looks at the selectivity
-- and found that ncic3 gives less result & hence first gets
-- c3 then applies c2.
-- Also the query cost for 1st is less than 2nd query.
Use TestDB
SET NOCOUNT ON
IF(SELECT OBJECT_ID('t1')) IS NOT NULL
  DROP TABLE t1
GO
CREATE TABLE t1(c1 INT, c2 INT)
CREATE CLUSTERED INDEX ci ON t1(c1)
DECLARE @n INT
SET @n = 1
WHILE @n <= 100
  BEGIN
  INSERT INTO t1 (c1, c2) VALUES(@n, @n)
  SET @n = @n + 1
END

-- check the logical read & worktable
SET STATISTICS IO ON
UPDATE t1 SET c1 = 55 WHERE c1 = 55
UPDATE t1 SET c1 = 123 WHERE c1 = 65
SET STATISTICS IO OFF


-- in the first query the update meant DELETE followed by an INSERT
-- because it finds the same unique rowid to be changed
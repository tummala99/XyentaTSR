Use TestDB
IF (SELECT OBJECT_ID('T1')) IS NOT NULL
	DROP TABLE T1
GO
CREATE TABLE T1(C1 INT, C2 INT)
CREATE INDEX I1 ON T1 (C1)
INSERT INTO T1 VALUES (11, 12)
GO

-- first swith on the display execution plan

SET STATISTICS IO ON
SELECT * FROM T1
SET STATISTICS IO OFF
GO

-- check logical reads
SET STATISTICS IO ON
SELECT * FROM T1 WHERE C1 = 11
SET STATISTICS IO OFF
GO

-- force the query to use index to see the impact on logical read
-- the read is higher than prev query
SET STATISTICS IO ON
SELECT * FROM T1 WITH (INDEX (I1)) WHERE C1 = 11
SET STATISTICS IO OFF

-- The lesson learnt is
	-- optimizer chooses the best execution plan
	-- in most cases it is not required to override the optimizer plan


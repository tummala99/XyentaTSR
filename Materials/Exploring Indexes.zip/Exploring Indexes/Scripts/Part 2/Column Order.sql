Use TestDB
SET NOCOUNT ON
IF(SELECT OBJECT_ID('t1')) IS NOT NULL
  DROP TABLE t1
GO
-- create a table with less no of rows and an index on (c1, c2)
CREATE TABLE t1(c1 INT, c2 INT IDENTITY, c3 CHAR(50))
CREATE INDEX i1 ON t1(c1, c2)

DECLARE @n INT
SET @n = 1
WHILE @n <= 100
  BEGIN
  INSERT INTO t1 (c1, c3) VALUES(@n, 'c3')
  SET @n = @n + 1
END

-- switch on the execution plan
-- will it be a scan or seek
SET STATISTICS IO ON
SELECT * FROM T1 WHERE C2=12
SET STATISTICS IO OFF

-- add 1400 rows
DECLARE @n INT
SET @n = 101
WHILE @n <= 1500
  BEGIN
  INSERT INTO t1 (c1, c3) VALUES(@n, 'c3')
  SET @n = @n + 1
END

-- what will be the scan now?
SET STATISTICS IO ON
SELECT * FROM T1 WHERE C2=12
SET STATISTICS IO OFF

-- let's create a new table with 1500 rows (same as t1)
IF(SELECT OBJECT_ID('t2')) IS NOT NULL
  DROP TABLE t2
CREATE TABLE t2(c1 INT, c2 INT IDENTITY, c3 CHAR(50))
CREATE INDEX i1 ON t2(c1, c2)
DECLARE @n INT
SET @n = 1
WHILE @n <= 1500
  BEGIN
  INSERT INTO t2 (c1, c3) VALUES(@n, 'c3')
  SET @n = @n + 1
END

-- what scan will the following query will use?
SET STATISTICS IO ON
SELECT * FROM T2 WHERE C2=12
SET STATISTICS IO OFF

-- discuss on the reason behind the two behaviors when both table have
-- same index & same no of rows?


-- the index was not rebuild.
-- now rebuild the index on t1 & then run the query
DBCC DBREINDEX ('t1') -- old method
ALTER INDEX i1 ON t1 REBUILD -- SQL Server 2005 way

-- now check the query
SET STATISTICS IO ON
SELECT * FROM T1 WHERE C2=12
SET STATISTICS IO OFF

-- create an index on 3 columns
CREATE INDEX i1 ON t1 (c2, c1, c3) WITH DROP_EXISTING

-- now guess what would happen in the following queries
SET STATISTICS IO ON
SELECT * FROM T1 WHERE C1=12
SELECT * FROM T1 WHERE C2=12 -- it directly gives the result without any joins..why?
SELECT * FROM T1 WHERE C3='c3'
SELECT * FROM T1 WHERE C1=12 AND C2=12
SET STATISTICS IO OFF


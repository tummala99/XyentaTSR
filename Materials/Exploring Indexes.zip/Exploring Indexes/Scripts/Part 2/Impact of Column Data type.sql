Use TestDB
SET NOCOUNT ON
IF(SELECT OBJECT_ID('t1')) IS NOT NULL
  DROP TABLE t1
GO
CREATE TABLE t1(c1 INT, c2 CHAR(4), c3 CHAR(900))
DECLARE @n INT
SET @n = 1
WHILE @n <= 500
BEGIN
  INSERT INTO t1 VALUES(@n, @n, @n)
  SET @n = @n + 1
END

-- are the foll query same?
SELECT * FROM T1 where c1 >  95
SELECT * FROM T1 where c2 >  95

SELECT * FROM T1 where c1 > '95'
SELECT * FROM T1 where c2 > '95'

-- check the output in the foll case
-- impact of mathematical expr on int & char col
SELECT MAX(c1), MAX(c2) FROM T1

-- now create an index on col 1 (int) and col 3 (char)
CREATE INDEX i1 ON t1 (c1)
CREATE INDEX i3 ON t1 (c3)

-- check the logical read in the following query
SET STATISTICS IO ON
SELECT * FROM T1 WHERE c1 = '10' OR c1 = '20' OR c1 = '30' 
SELECT * FROM T1 WHERE c3 = '10' OR c3 = '20' OR c3 = '30' 
SET STATISTICS IO OFF



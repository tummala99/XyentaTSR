Use TestDB
SET NOCOUNT ON
IF(SELECT OBJECT_ID('t1')) IS NOT NULL
  DROP TABLE t1
GO
CREATE TABLE t1(c1 INT, c2 INT)

-- insert 100 rows
DECLARE @n INT
SET @n = 1
WHILE @n <= 100 
  BEGIN
  INSERT INTO t1 VALUES(@n, @n+2)
  SET @n = @n + 1
END

-- on execution plan
-- Table Scan
SELECT * FROM t1 
SELECT c1, c2 FROM t1 WHERE c2 = 13

-- create a CI on c2
CREATE CLUSTERED INDEX ci ON t1 (c2)

-- will the following does table scan or CI scan?
-- is it ordered or unordered
SELECT * FROM t1 
SELECT * FROM t1 order by c2

-- drop the CI
DROP INDEX ci ON t1

-- what will happen in the following order by query?
SELECT * FROM t1 order by c2

-- create a NCI on c1
CREATE NONCLUSTERED INDEX nci ON t1 (c1)

-- check the following query
-- will it be a table scan or Index scan?
SELECT * FROM t1 
SELECT c1 FROM t1

-- will the following query use sort operator or not? 
SELECT c1 FROM t1 order by c1
SELECT c1 FROM t1 order by c2

-- recreate a CI on c2
CREATE CLUSTERED INDEX ci ON t1 (c2)

-- will it do a table scan, CI scan, or index scan
SELECT * FROM t1
SELECT * FROM t1 order by c1
SELECT * FROM t1 order by c2

-- recreate the table with 10000 rows & add one nci
IF(SELECT OBJECT_ID('t1')) IS NOT NULL
  DROP TABLE t1
GO
CREATE TABLE t1(c1 INT, c2 INT)
CREATE NONCLUSTERED INDEX nci ON t1(c1)

DECLARE @n INT
SET @n = 1
WHILE @n <= 10000
  BEGIN
  INSERT INTO t1 VALUES(@n, @n+2)
  SET @n = @n + 1
END

-- will it be a table scan or index scan (there is an index on c1)
SELECT * FROM t1
SELECT c1 FROM t1 
SELECT * FROM t1 order by c1


Use TestDB
SET NOCOUNT ON
IF(SELECT OBJECT_ID('t1')) IS NOT NULL
  DROP TABLE t1
GO
CREATE TABLE t1(c1 INT, c2 INT)

-- insert 100 rows
DECLARE @n INT
SET @n = 1
WHILE @n <= 100 
  BEGIN
  INSERT INTO t1 VALUES(@n, @n+2)
  SET @n = @n + 1
END

-- on execution plan
-- no indexes. check the foll query
SELECT * FROM t1 WHERE c1 = 10

-- create a CI on c2
CREATE CLUSTERED INDEX ci ON t1 (c1) 

-- will the foll be a index seek, index scan, table scan???
SELECT * FROM t1 WHERE c1 = 10
SELECT * FROM t1 WHERE c1 between 100 and 200

-- are the following two statements same? (assuming CI on c1) 
SELECT * FROM t1
SELECT * FROM t1 ORDER BY c1

-- drop the CI & create a NCI on c2
DROP INDEX ci ON t1
CREATE NONCLUSTERED INDEX nci ON t1 (c2) 

-- let's try the foll (will it be a index scan or table scan)
SELECT * FROM t1 WHERE c2 = 10
SELECT * FROM t1 WHERE c1 = 10

-- add 5000 rows to t1
DECLARE @n INT
SET @n = 101
WHILE @n <= 5500 
  BEGIN
  INSERT INTO t1 VALUES(@n, @n+2)
  SET @n = @n + 1
END

-- retry the same query
SELECT * FROM t1 WHERE c2 = 10
SELECT * FROM t1 WHERE c1 = 10

-- will the foll query uses RID?
SELECT c2 FROM t1 WHERE c2 = 10

-- recreate the table with 3 columns & 100 rows
-- create CI on c1 & NCI on c2
IF(SELECT OBJECT_ID('t1')) IS NOT NULL
  DROP TABLE t1
GO
CREATE TABLE t1(c1 INT, c2 INT, c3 INT)
CREATE CLUSTERED INDEX ci ON t1 (c1) 
CREATE NONCLUSTERED INDEX nci ON t1 (c2) 

-- insert 100 rows
DECLARE @n INT
SET @n = 1
WHILE @n <= 100 
  BEGIN
  INSERT INTO t1 VALUES(@n, @n+2, @n+4)
  SET @n = @n + 1
END

-- rerun the following query
SELECT c2 FROM t1 WHERE c2 = 10
SELECT c1, c2 FROM t1 WHERE c2 = 10

-- what is expected in the following case?
SELECT c1, c2, c3 FROM t1 WHERE c2 = 10

-- add additional row to check the above query again
DECLARE @n INT
SET @n = 101
WHILE @n <= 2000 
  BEGIN
  INSERT INTO t1 VALUES(@n, @n+2, @n+4)
  SET @n = @n + 1
END

-- recheck the query
SELECT c1, c2, c3 FROM t1 WHERE c2 = 10


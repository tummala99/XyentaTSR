Use TestDB
SET NOCOUNT ON
IF(SELECT OBJECT_ID('t1')) IS NOT NULL
  DROP TABLE t1
GO
CREATE TABLE t1(c1 INT, c2 CHAR(999), c3 VARCHAR(10))
CREATE CLUSTERED INDEX ci ON t1 (c1)

-- add 8 rows. It occupies one page
INSERT INTO t1 VALUES (1, 'c2', '')
INSERT INTO t1 VALUES (2, 'c2', '')
INSERT INTO t1 VALUES (3, 'c2', '')
INSERT INTO t1 VALUES (4, 'c2', '')
INSERT INTO t1 VALUES (5, 'c2', '')
INSERT INTO t1 VALUES (6, 'c2', '')
INSERT INTO t1 VALUES (7, 'c2', '')
INSERT INTO t1 VALUES (8, 'c2', '')

-- check the page data for the clustered index
SELECT avg_fragmentation_in_percent, page_count FROM
sys.dm_db_index_physical_stats(DB_ID('TestDB'), OBJECT_ID('t1'), 1, NULL , 'LIMITED');

-- insert an extra row
INSERT INTO t1 VALUES (9, 'c2', '')

-- check page data
SELECT avg_fragmentation_in_percent, page_count FROM
sys.dm_db_index_physical_stats(DB_ID('TestDB'), OBJECT_ID('t1'), 1, NULL , 'LIMITED');

-- insert 7 rows
INSERT INTO t1 VALUES (10, 'c2', '')
INSERT INTO t1 VALUES (11, 'c2', '')
INSERT INTO t1 VALUES (12, 'c2', '')
INSERT INTO t1 VALUES (13, 'c2', '')
INSERT INTO t1 VALUES (14, 'c2', '')
INSERT INTO t1 VALUES (15, 'c2', '')
INSERT INTO t1 VALUES (16, 'c2', '')

-- check page data
SELECT avg_fragmentation_in_percent, page_count FROM
sys.dm_db_index_physical_stats(DB_ID('TestDB'), OBJECT_ID('t1'), 1, NULL , 'LIMITED');


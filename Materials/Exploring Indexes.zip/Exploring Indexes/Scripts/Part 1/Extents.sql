Use TestDB
IF OBJECT_ID ('T1') IS NOT NULL
	DROP TABLE T1
CREATE TABLE T1 (C1 CHAR(8000))

sp_spaceused T1

-- insert 8 rows & check space used
INSERT T1 VALUES ('A1')
INSERT T1 VALUES ('A1')
INSERT T1 VALUES ('A1')
INSERT T1 VALUES ('A1')
INSERT T1 VALUES ('A1')
INSERT T1 VALUES ('A1')
INSERT T1 VALUES ('A1')
INSERT T1 VALUES ('A1')

sp_spaceused T1

-- now insert one row & check space used
INSERT T1 VALUES ('A1')

sp_spaceused T1

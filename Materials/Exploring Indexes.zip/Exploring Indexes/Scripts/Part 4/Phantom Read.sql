Use TestDB
SET NOCOUNT ON
IF(SELECT OBJECT_ID('TicketBooked')) IS NOT NULL
  DROP TABLE TicketBooked
GO
CREATE TABLE TicketBooked(TicketID INT IDENTITY, SeatsBooked INT) 

DECLARE @n INT
SET @n = 1
WHILE @n <= 20 
  BEGIN
  INSERT INTO TicketBooked VALUES(@n%5)
  SET @n = @n + 1
END

SELECT * FROM TicketBooked WHERE TicketID BETWEEN 5 AND 10

-- Window 1
-- Read multiple time the seats in the same transaction
BEGIN TRAN
	SELECT * FROM TicketBooked WHERE TicketID BETWEEN 5 AND 10
	WAITFOR DELAY '00:00:03'
	SELECT * FROM TicketBooked WHERE TicketID BETWEEN 5 AND 10
COMMIT TRAN

-- Window 2
-- Execute a delete statement that belong to one row within the range 5 - 10
Use TestDB
DELETE FROM TicketBooked WHERE TicketID = 7

-- to avoid the phantom, the delete shouldn't be allowed to update the
-- records between 5 and 10
-- This can be tested by using the SERIALIZABLE option which is the
-- highest level of isolation setting

-- Recreat the table 
-- Window 1
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE 
BEGIN TRAN
	SELECT * FROM TicketBooked WHERE TicketID BETWEEN 5 AND 10
	WAITFOR DELAY '00:00:03'
	SELECT * FROM TicketBooked WHERE TicketID BETWEEN 5 AND 10
COMMIT TRAN

-- Window 2
DELETE FROM TicketBooked WHERE TicketID = 7

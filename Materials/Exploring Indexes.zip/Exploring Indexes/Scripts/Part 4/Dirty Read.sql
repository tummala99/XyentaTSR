-- Dirty Read
Use TestDB
SET NOCOUNT ON
IF(SELECT OBJECT_ID('AirlineReservation')) IS NOT NULL
  DROP TABLE AirlineReservation
GO
CREATE TABLE AirlineReservation(SeatsAvailable INT)

INSERT AirlineReservation VALUES (10)

-- check the no of seats available
SELECT * FROM AirlineReservation

-- Window 1
-- update the no of seats available to 20 in a transaction
BEGIN TRAN
	UPDATE AirlineReservation SET SeatsAvailable = 20
	WAITFOR DELAY '00:00:05'
ROLLBACK TRAN

-- Window 2
-- Read the seats available
Use TestDB
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SELECT * FROM AirlineReservation
WAITFOR DELAY '00:00:10'
SELECT * FROM AirlineReservation

-- Now check the DATA
SELECT * FROM AirlineReservation


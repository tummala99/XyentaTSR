Use TestDB
SET NOCOUNT ON
IF(SELECT OBJECT_ID('AirlineReservation')) IS NOT NULL
  DROP TABLE AirlineReservation
IF(SELECT OBJECT_ID('TicketBooked')) IS NOT NULL
  DROP TABLE TicketBooked
GO
CREATE TABLE AirlineReservation(SeatsAvailable INT)
CREATE TABLE TicketBooked(TicketID INT IDENTITY, SeatsBooked INT) 

INSERT AirlineReservation VALUES (10)

-- check the no of seats available
SELECT * FROM AirlineReservation

-- Window 1
-- start the booking for 5 people
DECLARE @FreeSeats INT
SELECT @FreeSeats = SeatsAvailable FROM AirlineReservation
WAITFOR DELAY '00:00:05'

IF @FreeSeats > 5 
BEGIN
	INSERT TicketBooked VALUES (5)
	UPDATE AirlineReservation SET SeatsAvailable = SeatsAvailable - 5
	PRINT 'Successfully Reserved for 5 People'
END

-- Window 2
-- in another window start the booking for 7 people
Use TestDB
GO
DECLARE @FreeSeats INT
SELECT @FreeSeats = SeatsAvailable FROM AirlineReservation
WAITFOR DELAY '00:00:10'

IF @FreeSeats > 7 
BEGIN
	INSERT TicketBooked VALUES (7)
	UPDATE AirlineReservation SET SeatsAvailable = SeatsAvailable - 7
	PRINT 'Successfully Reserved for 7 People'
END

-- Now check both the tables
SELECT * FROM AirlineReservation
SELECT * FROM TicketBooked

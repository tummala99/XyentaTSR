Use TestDB
SET NOCOUNT ON
IF(SELECT OBJECT_ID('t1')) IS NOT NULL
  DROP TABLE t1
GO
-- creata a Heap
CREATE TABLE t1(c1 INT)
INSERT INTO t1 VALUES ('1')

-- Start a Delete transaction
BEGIN TRAN
	DELETE FROM t1 WHERE c1 = 1
	-- SQL Server 2000
	EXEC sp_lock @@SPID -- displays lock held by the delete statement
	-- SQL Server 2005
	SELECT resource_type, resource_associated_entity_id, 
		request_status, request_mode, 
		resource_database_id, resource_description 
    FROM sys.dm_tran_locks
    WHERE request_session_id = @@SPID
COMMIT TRAN

-- The above tran acquires a RID lock because it is a heap

-- Obtain the information of database & table from the ids (output of sp_lock)
-- present in the prev query
SELECT OBJECT_NAME(493244812)
SELECT DB_NAME(8)


Use TestDB
SET NOCOUNT ON
IF(SELECT OBJECT_ID('AirlineReservation')) IS NOT NULL
  DROP TABLE AirlineReservation
GO
CREATE TABLE AirlineReservation(SeatsAvailable INT)

INSERT AirlineReservation VALUES (10)

-- check the no of seats available
SELECT * FROM AirlineReservation

-- Window 1
-- Read multiple time the seats in the same transaction
BEGIN TRAN
	SELECT * FROM AirlineReservation
	WAITFOR DELAY '00:00:03'
	SELECT * FROM AirlineReservation
	WAITFOR DELAY '00:00:03'
	SELECT * FROM AirlineReservation
COMMIT TRAN

-- Window 2
-- update the seats and commit changes (in dirty read example
-- there was no commit of the data)
-- As there is no begin..commit tran, it is implict transaction
Use TestDB
UPDATE AirlineReservation SET SeatsAvailable = 20
WAITFOR DELAY '00:00:03'
UPDATE AirlineReservation SET SeatsAvailable = 30
WAITFOR DELAY '00:00:05'
UPDATE AirlineReservation SET SeatsAvailable = 40

-- To understand the impact of putting all of the UPDATE into one TRANSACTIOn
-- run with Window 1 and the following query in parallel 
Use TestDB
BEGIN TRAN
	UPDATE AirlineReservation SET SeatsAvailable = 20
	WAITFOR DELAY '00:00:03'
	UPDATE AirlineReservation SET SeatsAvailable = 30
	WAITFOR DELAY '00:00:05'
	UPDATE AirlineReservation SET SeatsAvailable = 40
COMMIT TRAN
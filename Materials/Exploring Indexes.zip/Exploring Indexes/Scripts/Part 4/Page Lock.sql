Use TestDB
SET NOCOUNT ON
IF(SELECT OBJECT_ID('t1')) IS NOT NULL
  DROP TABLE t1
GO
-- insert 5000 rows
CREATE TABLE t1(c1 INT, c2 INT)
DECLARE @n INT
SET @n = 1
WHILE @n <= 5000
  BEGIN
  INSERT INTO t1 VALUES(@n, 1)
  SET @n = @n + 1
END

-- Start a Delete transaction
-- check the no of RID locks. Is there any PAG lock present? 
BEGIN TRAN
	DELETE FROM t1 
	EXEC sp_lock @@SPID 
COMMIT TRAN
-- Is the above locking mechanism expensive?

-- insert 8000 rows & check the delete tran again
DECLARE @n INT
SET @n = 1
WHILE @n <= 8000
  BEGIN
  INSERT INTO t1 VALUES(@n, 1)
  SET @n = @n + 1
END

-- Start a Delete transaction
-- check the no of RID locks. Is there any PAG lock present? 
BEGIN TRAN
	DELETE FROM t1 
	EXEC sp_lock @@SPID 
COMMIT TRAN


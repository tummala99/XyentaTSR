Use TestDB
SET NOCOUNT ON
IF(SELECT OBJECT_ID('t1')) IS NOT NULL
  DROP TABLE t1
GO
CREATE TABLE t1(c1 INT, c2 INT) 
DECLARE @n INT
SET @n = 1
WHILE @n <= 10000
  BEGIN
  INSERT INTO t1 VALUES(@n, 1)-- 1)
  SET @n = @n + 1
END

-- Start a Delete transaction
-- Check the TAB lock at the end of list. There are 2 rows
-- with TAB one for the master database & other for TestDB
BEGIN TRAN
	DELETE FROM t1 
	EXEC sp_lock @@SPID 
COMMIT TRAN

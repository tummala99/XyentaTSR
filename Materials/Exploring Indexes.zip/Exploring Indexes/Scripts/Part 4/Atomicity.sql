Use TestDB
SET NOCOUNT ON
IF(SELECT OBJECT_ID('t1')) IS NOT NULL
  DROP TABLE t1
GO
CREATE TABLE t1(c1 INT CONSTRAINT chk_c1 CHECK (c1 = 1))
GO

-- Implicit transaction
INSERT INTO t1 VALUES ('1')

-- Explicit transaction
-- what would happen?
BEGIN TRAN
	INSERT INTO t1 VALUES ('2')
	INSERT INTO t1 VALUES ('1')
COMMIT TRAN

-- check the data
SELECT * FROM t1

-- setting XACT_ABORT option for increasing the atomicity
SET XACT_ABORT ON
-- run the transaction now
BEGIN TRAN
	INSERT INTO t1 VALUES ('2')
	INSERT INTO t1 VALUES ('1')
COMMIT TRAN
SET XACT_ABORT OFF

-- recheck the data
SELECT * FROM t1

-- using ROLLBACK to maintain atomicity 
BEGIN TRAN
	-- First statement
	INSERT INTO t1 VALUES ('2')
	IF @@ERROR <> 0
	BEGIN
		ROLLBACK --Optional, since there is nothing to undo
		RETURN --Prevent any further execution
	END
	--Second statement
	INSERT INTO t1 VALUES ('1')
	IF @@ERROR <> 0
	BEGIN
		ROLLBACK --Optional, since there is nothing to undo
		RETURN --Prevent any further execution
	END
COMMIT TRAN

-- recheck the data
SELECT * FROM t1

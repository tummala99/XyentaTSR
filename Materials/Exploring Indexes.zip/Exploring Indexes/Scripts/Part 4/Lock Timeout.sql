Use TestDB
SET NOCOUNT ON
IF(SELECT OBJECT_ID('t1')) IS NOT NULL
  DROP TABLE t1
GO
CREATE TABLE t1(c1 INT, c2 INT) 
DECLARE @n INT
SET @n = 1
WHILE @n <= 1000
  BEGIN
  INSERT INTO t1 VALUES(@n, 1)-- 1)
  SET @n = @n + 1
END

-- Window 1
-- Start a Delete transaction
BEGIN TRAN
	SELECT * FROM t1 WITH (REPEATABLEREAD) WHERE c1 = 100
	WAITFOR DELAY '00:00:10'	
COMMIT TRAN

-- Window 2
-- First test without setting the lock timeout
SELECT @@LOCK_TIMEOUT
SET LOCK_TIMEOUT 5000
UPDATE t1 SET c1 = 100 WHERE c1 = 100

-- Window 2
-- Now test after setting the lock timeout for 5 secs
SET LOCK_TIMEOUT 5000
SELECT @@LOCK_TIMEOUT
UPDATE t1 SET c1 = 100 WHERE c1 = 100

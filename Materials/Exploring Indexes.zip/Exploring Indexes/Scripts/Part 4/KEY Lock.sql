Use TestDB
SET NOCOUNT ON
IF(SELECT OBJECT_ID('t1')) IS NOT NULL
  DROP TABLE t1
GO
-- A table with clustered index
CREATE TABLE t1(c1 INT, c2 INT IDENTITY)
CREATE CLUSTERED INDEX i1 ON t1(c1)
INSERT INTO t1 VALUES ('1')
INSERT INTO t1 VALUES ('2')
INSERT INTO t1 VALUES ('3')

-- Start a Delete transaction
BEGIN TRAN
	DELETE FROM t1 WHERE c1 = 1
	EXEC sp_lock @@SPID -- displays lock held by the delete statement
COMMIT TRAN

-- A table with non clustered index
DROP INDEX i1 on t1
CREATE NONCLUSTERED INDEX i1 ON t1(c1)

-- check the lock now
-- Start a Delete transaction. Note the IndId column
BEGIN TRAN
	DELETE FROM t1 WHERE c1 = 2
	EXEC sp_lock @@SPID 
COMMIT TRAN
-- it holds exclusive lock on KEY and RID

-- A table with clustered & NCI
DROP INDEX i1 on t1
CREATE CLUSTERED INDEX i1 ON t1(c1)
CREATE NONCLUSTERED INDEX i2 ON t1(c2)

-- check the lock now
-- Start a Delete transaction. Note the IndId column
BEGIN TRAN
	DELETE FROM t1 WHERE c1 = 3
	EXEC sp_lock @@SPID 
COMMIT TRAN
-- it holds exclusive lock on KEY and PAG (as RID does not exist)

-- Key Range Lock
-- insert one row since all other rows were deleted
INSERT INTO t1 VALUES ('4')
SELECT * FROM t1

-- check the RangeS with the foll query
BEGIN TRAN
	SELECT * FROM t1 WITH (SERIALIZABLE) WHERE c1 BETWEEN 2 AND 5
	EXEC sp_lock @@SPID 
COMMIT TRAN

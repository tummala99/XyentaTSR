Use TestDB
SET NOCOUNT ON
IF(SELECT OBJECT_ID('t1')) IS NOT NULL
  DROP TABLE t1
GO
CREATE TABLE t1(c1 INT, c2 DATETIME) 
INSERT INTO t1 VALUES (1, GETDATE())
GO

-- Window 1
-- Start a read transaction 
BEGIN TRAN Tx1
-- Repeatable read ensure that the S lock is held till the tran end
SELECT * FROM t1 WITH (REPEATABLEREAD) WHERE c1 = 1
EXEC sp_lock @@SPID
WAITFOR DELAY '00:00:10'
COMMIT

-- Window 2
-- Start an update transaction. 
Use TestDB
BEGIN TRAN Tx2
UPDATE t1 SET c2 = GETDATE() WHERE c1 = 1
EXEC sp_lock @@SPID
WAITFOR DELAY '00:00:05'
COMMIT

-- Windows 3
EXEC sp_lock

-- see how U lock was held & request raised for converting to X lock
-- in the 3rd window 




